﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace VY_proje
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        SqlConnection baglanti;

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti = new SqlConnection(@"Data Source=EGEMEN\SQLEXPRESS;Initial Catalog=projeDB;Integrated Security=True");
                baglanti.Open();

                string sql = "insert into urun_kayit(UrunID,UrunAD,Fiyat) values (@UrunID,@UrunAD,@Fiyat)";
                SqlCommand komut = new SqlCommand(sql, baglanti);

                komut.Parameters.AddWithValue("@UrunID", ID.Text);
                komut.Parameters.AddWithValue("@UrunAD", AD.Text);
                komut.Parameters.AddWithValue("@Fiyat", Fiyat.Text);


                komut.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Ürün Kayıt İşlemi Gerçekleşti.");
            }
            catch (Exception hata)
            {
                MessageBox.Show("İşlem Sırasında Hata Oluştu." + hata.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti = null;
            try
            {
                baglanti = new SqlConnection(@"Data Source=EGEMEN\SQLEXPRESS;Initial Catalog=projeDB;Integrated Security=True");
                baglanti.Open();

                SqlCommand cmd = new SqlCommand("SELECT UrunID,UrunAD,Fiyat FROM urun_kayit", baglanti);
                SqlDataReader sqlDR = cmd.ExecuteReader();
                richTextBox1.Text = richTextBox1.Text + String.Format("{0,-15}| {1,-15}| {2,5}", "ID", "Urun Adı", "Fiyat") + "\n";
                while (sqlDR.Read())
                {
                    string id = sqlDR[0].ToString();
                    string urun_adi = sqlDR[1].ToString();
                    string fiyat = sqlDR[2].ToString();

                    richTextBox1.Text = richTextBox1.Text + String.Format("{0,-15}| {1,-15}| {2,5}", id, urun_adi, fiyat) + "\n";
                }
                richTextBox1.Text = richTextBox1.Text + "--------------------------------------\n";
            }
            catch (Exception ex)
            {
                MessageBox.Show("SQL Query sırasında hata oluştu !" + ex.ToString());
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            baglanti = new SqlConnection(@"Data Source=EGEMEN\SQLEXPRESS;Initial Catalog=projeDB;Integrated Security=True");
            baglanti.Open();
            string secmeSorgusu = "SELECT * from urun_kayit where UrunID=@UrunID";
            SqlCommand secmeKomutu = new SqlCommand(secmeSorgusu, baglanti);
            secmeKomutu.Parameters.AddWithValue("@UrunID", RID.Text);
            SqlDataReader dr = secmeKomutu.ExecuteReader();
            if (dr.Read()) 
            {
                string isim = dr["UrunAD"].ToString() + " " + dr["Fiyat"].ToString();
                dr.Close();
                DialogResult durum = MessageBox.Show(isim + " kaydını silmek istediğinizden emin misiniz?", "Silme Onayı", MessageBoxButtons.YesNo);
                if (DialogResult.Yes == durum)
                {
                    string silmeSorgusu = "DELETE from urun_kayit where UrunID=@UrunID";
                    SqlCommand silKomutu = new SqlCommand(silmeSorgusu, baglanti);
                    silKomutu.Parameters.AddWithValue("@UrunID", RID.Text);
                    silKomutu.ExecuteNonQuery();
                    MessageBox.Show("Kayıt Silindi...");  
                }
            }
            else
                MessageBox.Show("Ürün Bulunamadı...");
            baglanti.Close();
        }

        private void ID_TextChanged(object sender, EventArgs e)
        {

        }

        private void Fiyat_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void AD_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
