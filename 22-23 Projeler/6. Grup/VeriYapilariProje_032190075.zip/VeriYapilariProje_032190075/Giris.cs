﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace VY_proje
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti;
            baglanti = new SqlConnection(@"Data Source=EGEMEN\SQLEXPRESS;Initial Catalog=projeDB;Integrated Security=True");
            baglanti.Open();
            string secmeSorgusu = "SELECT Parola FROM yonetici_kayit WHERE Mail=@Mail";
            string secmeSorgusu2 = "SELECT Mail FROM yonetici_kayit";
            string mail = textBox1.Text;
            string sifre = textBox2.Text;
            string[] list = new string[10];
            SqlCommand cmd = new SqlCommand(secmeSorgusu, baglanti);
            SqlCommand cmd2 = new SqlCommand(secmeSorgusu2, baglanti);
            cmd.Parameters.AddWithValue("@Mail", textBox1.Text);
            SqlDataReader dr2 = cmd2.ExecuteReader();
            int i = 0;
                while (dr2.Read())
                {
                string input = dr2.GetString(i);
                list[i] = input;
                i++;
                }
                dr2.Close();
            int sonuc = 0;
            for (int j = 0; j < list.Length; j++)
            {
                if (list[j] == mail)
                    sonuc = 1;
                break;
            }
            if (sonuc == 0)
                MessageBox.Show("E-Mail veya Parola Hatalı");
            SqlDataReader dr = cmd.ExecuteReader();
            
                while (dr.Read())
                {
                if (sifre == dr[0].ToString())
                {
                    MessageBox.Show("Giriş Başarılı");
                    Secim form = new Secim();
                    form.ShowDialog();
                    break;
                }
                else if (dr[0].ToString() != sifre)
                {
                    MessageBox.Show("E-Mail veya Parola Hatalı");
                    break;
                }
                    
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Giris_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
