﻿using System.Data.SqlClient;

namespace VY_proje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent(); 
        }

        SqlConnection baglanti;
        private void button4_Click(object sender, EventArgs e)
        {
            
            try
            {
                baglanti = new SqlConnection(@"Data Source=EGEMEN\SQLEXPRESS;Initial Catalog=projeDB;Integrated Security=True");
                baglanti.Open();

                SqlCommand cmd = new SqlCommand("SELECT PersonelAD,PersonelSoyad,PersonelID,PersonelMaas,PersonelTelNo FROM personel_kayit", baglanti);
                SqlDataReader sqlDR = cmd.ExecuteReader();
                richTextBox2.Text = richTextBox2.Text + String.Format("{0,-20}| {1,-16}| {2,-20}| {3,-10}| {4,15}", "AD", "Soyad", "ID", "Maas", "Telefon") + "\n";
                while (sqlDR.Read())
                {
                    string ad = sqlDR[0].ToString();
                    string soyad = sqlDR[1].ToString();
                    string id = sqlDR[2].ToString();
                    string maas = sqlDR[3].ToString();
                    string tel = sqlDR[4].ToString();

                    richTextBox2.Text = richTextBox2.Text + String.Format("{0,-15}| {1,-15}| {2,-15}| {3,-7}| {4,15}", ad, soyad, id, maas, tel) + "\n";
                }
                richTextBox2.Text = richTextBox2.Text + "----------------------------------------------------------------\n";
            }
            catch (Exception ex)
            {
                MessageBox.Show("SQL Query sırasında hata oluştu !" + ex.ToString());
            }
            finally
            {
                if (baglanti != null)
                    baglanti.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti = new SqlConnection(@"Data Source=EGEMEN\SQLEXPRESS;Initial Catalog=projeDB;Integrated Security=True");
                baglanti.Open();

                string sql = "insert into personel_kayit(PersonelAd,PersonelSoyad,PersonelID,PersonelTelNo,PersonelMaas) values (@PersonelAd,@PersonelSoyad,@PersonelID,@PersonelTelNo,@PersonelMaas)";
                SqlCommand komut = new SqlCommand(sql, baglanti);

                komut.Parameters.AddWithValue("@PersonelAd", pa.Text);
                komut.Parameters.AddWithValue("@PersonelSoyad", ps.Text);
                komut.Parameters.AddWithValue("@PersonelID", pid.Text);
                komut.Parameters.AddWithValue("@PersonelTelno", pt_.Text);
                komut.Parameters.AddWithValue("@PersonelMaas", pm.Text);


                komut.ExecuteNonQuery();
                baglanti.Close();
                MessageBox.Show("Personel Kayıt İşlemi Gerçekleşti.");
            }
            catch (Exception hata)
            {
                MessageBox.Show("İşlem Sırasında Hata Oluştu.\n" + hata.Message);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {

            baglanti = new SqlConnection(@"Data Source=EGEMEN\SQLEXPRESS;Initial Catalog=projeDB;Integrated Security=True");
            baglanti.Open();
            string secmeSorgusu = "SELECT * from personel_kayit where PersonelID=@PersonelID";
            SqlCommand secmeKomutu = new SqlCommand(secmeSorgusu, baglanti);
            secmeKomutu.Parameters.AddWithValue("@PersonelID", rpid.Text);
            SqlDataReader dr = secmeKomutu.ExecuteReader();
            if (dr.Read()) 
            {
                string isim = dr["PersonelAD"].ToString() + " " + dr["PersonelSoyad"].ToString();
                dr.Close();
                DialogResult durum = MessageBox.Show(isim + " kaydını silmek istediğinizden emin misiniz?", "Silme Onayı", MessageBoxButtons.YesNo);
              
                if (DialogResult.Yes == durum) 
                {
                    string silmeSorgusu = "DELETE from personel_kayit where PersonelID=@PersonelID";
                    SqlCommand silKomutu = new SqlCommand(silmeSorgusu, baglanti);
                    silKomutu.Parameters.AddWithValue("@PersonelID", rpid.Text);
                    silKomutu.ExecuteNonQuery();
                    MessageBox.Show("Kayıt Silindi...");
                }
            }
            else
                MessageBox.Show("Personel Bulunamadı...");
            baglanti.Close();
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       

        private void pa_TextChanged(object sender, EventArgs e)
        {

        }

        private void ps_TextChanged(object sender, EventArgs e)
        {

        }

        private void pid_TextChanged(object sender, EventArgs e)
        {

        }

        private void pm_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}